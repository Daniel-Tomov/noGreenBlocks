package me.cageydinosaur.nogreenblocks;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StartGame implements CommandExecutor {
	
	Main plugin;
	public StartGame(Main plugin) {
		plugin = this.plugin;
	}
	public static boolean gamestarted = false;

	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		if (sender.hasPermission("nogreenblocks")) {
			if (args.length == 0) {
				sender.sendMessage(ChatColor.RED + "Usage:");
				sender.sendMessage(ChatColor.RED + "/nogreenblocks toggle");
				sender.sendMessage(ChatColor.RED + "/nogreenblocks help");
			} else if (args.length > 0) {
				if (args[0].equalsIgnoreCase("toggle")) {
					if (!gamestarted) {
						if (sender instanceof Player) {
							Bukkit.broadcastMessage(ChatColor.GREEN + "NoGreenBlocks Challenge has begun!");
							gamestarted = true;
						}
					} else if (gamestarted) {
						if (sender instanceof Player) {
							Bukkit.broadcastMessage(ChatColor.GREEN + "NoGreenBlocks Challenge has ended!");
							gamestarted = false;
						}

						return true;
					}
				} else if (args[0].equalsIgnoreCase("help")) {
					sender.sendMessage(ChatColor.RED + "Usage:");
					sender.sendMessage(ChatColor.RED + "/nogreenblocks toggle");
					sender.sendMessage(ChatColor.RED + "/nogreenblocks help");
				} else if (args[0].equalsIgnoreCase("reload")) {
					plugin.reloadConfig();
				}
			}
		} else {
			sender.sendMessage(ChatColor.RED + "You do not have the permission needed to run this command");
		}

		return true;

	}
}
