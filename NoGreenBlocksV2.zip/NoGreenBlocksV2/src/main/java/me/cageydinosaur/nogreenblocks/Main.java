package me.cageydinosaur.nogreenblocks;

import org.bukkit.plugin.java.JavaPlugin;


public final class Main extends JavaPlugin {
	public boolean gamestarted = false;
    public void onEnable() {
        this.getServer().getPluginManager().registerEvents(new PlayerMoveListener(this), this);
        getCommand("nogreenblocks").setExecutor(new StartGame(this));
    }
}