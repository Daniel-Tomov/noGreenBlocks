package me.cageydinosaur.nogreenblocks;

import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class PlayerMoveListener implements Listener {
	Main plugin;

	public PlayerMoveListener(Main plugin) {
		plugin = this.plugin;
	}

	@EventHandler
	public void onPlayerMove(PlayerMoveEvent e) {
		if (StartGame.gamestarted) {
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.ACACIA_LEAVES) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.OAK_LEAVES) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.DARK_OAK_LEAVES) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.BIRCH_LEAVES) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.SPRUCE_LEAVES) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.JUNGLE_LEAVES) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GREEN_WOOL) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GREEN_TERRACOTTA) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GREEN_CARPET) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GREEN_STAINED_GLASS) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GREEN_STAINED_GLASS_PANE) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GREEN_BED) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GREEN_GLAZED_TERRACOTTA) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GREEN_CONCRETE) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GREEN_CONCRETE_POWDER) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LIME_WOOL) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LIME_TERRACOTTA) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LIME_CARPET) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LIME_STAINED_GLASS) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LIME_STAINED_GLASS_PANE) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LIME_BED) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LIME_GLAZED_TERRACOTTA) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LIME_CONCRETE) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LIME_CONCRETE_POWDER) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.EMERALD_ORE) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.EMERALD_BLOCK) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GRASS_BLOCK) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.GRASS) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LILY_PAD) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.SEAGRASS) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.VINE) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.FERN) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.LARGE_FERN) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.SUGAR_CANE) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.BAMBOO) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.BAMBOO_SAPLING) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.CACTUS) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.WARPED_HYPHAE) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.STRIPPED_WARPED_HYPHAE) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.WARPED_STEM) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.WARPED_PLANKS) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.WARPED_NYLIUM) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.STRIPPED_WARPED_STEM) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.WARPED_FUNGUS) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.WARPED_ROOTS) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}

			if (e.getTo().getBlock().getRelative(BlockFace.DOWN).getType() == Material.WARPED_WART_BLOCK) {
				Player p = e.getPlayer();
				p.setHealth(0);

				return;
			}
		}

	}
}
